package model

import "fmt"

// Printing Hello World 
func main() {
	fmt.Println("Hello World")
}